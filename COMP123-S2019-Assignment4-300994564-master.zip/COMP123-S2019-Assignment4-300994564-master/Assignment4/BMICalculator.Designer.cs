﻿namespace Assignment4
{
    partial class BMICalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.WeighttextBox = new System.Windows.Forms.TextBox();
            this.Weight = new System.Windows.Forms.Label();
            this.HeighttextBox = new System.Windows.Forms.TextBox();
            this.height = new System.Windows.Forms.Label();
            this.BMItextBox = new System.Windows.Forms.TextBox();
            this.CalculateBMIbutton = new System.Windows.Forms.Button();
            this.ImperialUnitButton = new System.Windows.Forms.RadioButton();
            this.MetricUnitButton = new System.Windows.Forms.RadioButton();
            this.ResetButton = new System.Windows.Forms.Button();
            this.BMIlabel = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.WeighttextBox, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.Weight, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.HeighttextBox, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.height, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 114);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(294, 99);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // WeighttextBox
            // 
            this.WeighttextBox.Location = new System.Drawing.Point(150, 52);
            this.WeighttextBox.Name = "WeighttextBox";
            this.WeighttextBox.Size = new System.Drawing.Size(100, 38);
            this.WeighttextBox.TabIndex = 3;
            this.WeighttextBox.TextChanged += new System.EventHandler(this.inputbox_changed);
            // 
            // Weight
            // 
            this.Weight.AutoSize = true;
            this.Weight.Location = new System.Drawing.Point(3, 49);
            this.Weight.Name = "Weight";
            this.Weight.Size = new System.Drawing.Size(141, 31);
            this.Weight.TabIndex = 1;
            this.Weight.Text = "My Weight";
            this.Weight.Click += new System.EventHandler(this.Weight_Click);
            // 
            // HeighttextBox
            // 
            this.HeighttextBox.Location = new System.Drawing.Point(150, 3);
            this.HeighttextBox.Name = "HeighttextBox";
            this.HeighttextBox.Size = new System.Drawing.Size(100, 38);
            this.HeighttextBox.TabIndex = 2;
            this.HeighttextBox.TextChanged += new System.EventHandler(this.inputbox_changed);
            // 
            // height
            // 
            this.height.AutoSize = true;
            this.height.Location = new System.Drawing.Point(3, 0);
            this.height.Name = "height";
            this.height.Size = new System.Drawing.Size(136, 31);
            this.height.TabIndex = 0;
            this.height.Text = "My Height";
            this.height.Click += new System.EventHandler(this.Height_Click);
            // 
            // BMItextBox
            // 
            this.BMItextBox.Location = new System.Drawing.Point(96, 282);
            this.BMItextBox.Name = "BMItextBox";
            this.BMItextBox.Size = new System.Drawing.Size(155, 38);
            this.BMItextBox.TabIndex = 3;
            this.BMItextBox.TextChanged += new System.EventHandler(this.BMItextBox_TextChanged);
            // 
            // CalculateBMIbutton
            // 
            this.CalculateBMIbutton.Location = new System.Drawing.Point(96, 342);
            this.CalculateBMIbutton.Name = "CalculateBMIbutton";
            this.CalculateBMIbutton.Size = new System.Drawing.Size(196, 43);
            this.CalculateBMIbutton.TabIndex = 4;
            this.CalculateBMIbutton.Text = "CalculateBMI";
            this.CalculateBMIbutton.UseVisualStyleBackColor = true;
            this.CalculateBMIbutton.Click += new System.EventHandler(this.CalculateBMIbutton_Click);
            // 
            // ImperialUnitButton
            // 
            this.ImperialUnitButton.AutoSize = true;
            this.ImperialUnitButton.Location = new System.Drawing.Point(12, 12);
            this.ImperialUnitButton.Name = "ImperialUnitButton";
            this.ImperialUnitButton.Size = new System.Drawing.Size(128, 35);
            this.ImperialUnitButton.TabIndex = 6;
            this.ImperialUnitButton.TabStop = true;
            this.ImperialUnitButton.Text = "Imperial";
            this.ImperialUnitButton.UseVisualStyleBackColor = true;
            this.ImperialUnitButton.CheckedChanged += new System.EventHandler(this.MetricUnitButton_CheckedChanged_1);
            // 
            // MetricUnitButton
            // 
            this.MetricUnitButton.AutoSize = true;
            this.MetricUnitButton.Location = new System.Drawing.Point(12, 64);
            this.MetricUnitButton.Name = "MetricUnitButton";
            this.MetricUnitButton.Size = new System.Drawing.Size(106, 35);
            this.MetricUnitButton.TabIndex = 7;
            this.MetricUnitButton.TabStop = true;
            this.MetricUnitButton.Text = "Metric";
            this.MetricUnitButton.UseVisualStyleBackColor = true;
            this.MetricUnitButton.CheckedChanged += new System.EventHandler(this.MetricUnitButton_CheckedChanged_1);
            // 
            // ResetButton
            // 
            this.ResetButton.Location = new System.Drawing.Point(96, 391);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(196, 39);
            this.ResetButton.TabIndex = 8;
            this.ResetButton.Text = "Reset";
            this.ResetButton.UseVisualStyleBackColor = true;
            this.ResetButton.Click += new System.EventHandler(this.Reset);
            // 
            // BMIlabel
            // 
            this.BMIlabel.AutoSize = true;
            this.BMIlabel.Location = new System.Drawing.Point(56, 248);
            this.BMIlabel.Name = "BMIlabel";
            this.BMIlabel.Size = new System.Drawing.Size(62, 31);
            this.BMIlabel.TabIndex = 9;
            this.BMIlabel.Text = "BMI";
            // 
            // BMICalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(304, 442);
            this.Controls.Add(this.BMIlabel);
            this.Controls.Add(this.ResetButton);
            this.Controls.Add(this.MetricUnitButton);
            this.Controls.Add(this.ImperialUnitButton);
            this.Controls.Add(this.CalculateBMIbutton);
            this.Controls.Add(this.BMItextBox);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.MaximizeBox = false;
            this.Name = "BMICalculator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BMICalculator";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.BMICalculator_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox WeighttextBox;
        private System.Windows.Forms.Label Weight;
        private System.Windows.Forms.Label height;
        private System.Windows.Forms.TextBox HeighttextBox;
        private System.Windows.Forms.TextBox BMItextBox;
        private System.Windows.Forms.Button CalculateBMIbutton;
        private System.Windows.Forms.RadioButton ImperialUnitButton;
        private System.Windows.Forms.RadioButton MetricUnitButton;
        private System.Windows.Forms.Button ResetButton;
        private System.Windows.Forms.Label BMIlabel;
    }
}

