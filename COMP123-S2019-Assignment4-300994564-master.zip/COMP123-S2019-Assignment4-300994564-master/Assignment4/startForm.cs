﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment4
{
    public partial class startForm : Form
    {
        public startForm()
        {
            InitializeComponent();
        }

        private void startForm_Load(object sender, EventArgs e)
        {
            Timer.Enabled = true;

        }

        private void Splashtimer_Tick(object sender, EventArgs e)
        {
            Timer.Enabled = false;
            Program.BMICalculator.Show();
            Program.startForm.Hide();
        }
    }
}
