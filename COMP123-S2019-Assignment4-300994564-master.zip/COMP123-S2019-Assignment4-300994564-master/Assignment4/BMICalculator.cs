﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment4
{
    public partial class BMICalculator : Form
    {
        public BMICalculator()
        {
            InitializeComponent();
        }

        private void CalculateBMIbutton_Click(object sender, EventArgs e)
        {
            double Result = 0;
            double weight = 0;
            double height = 0;
            if (   WeighttextBox.Text != "0"   &&    HeighttextBox.Text != "0")
            {

               
                if (Double.TryParse(WeighttextBox.Text, out weight) && Double.TryParse(HeighttextBox.Text, out height))
                {
                    if (MetricUnitButton.Checked)
                    {
                        Result = weight / Math.Pow(height, 2);
                        BMItextBox.Text = "" + Math.Round(Result, 1);
                    }
                    else
                    {
                        Result = (weight * 703) / Math.Pow(height, 2);
                        BMItextBox.Text = "" + Math.Round(Result, 1);
                    }
                   
                    ShowResults();
                }
                else
                {
                    displayofResults();
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            displayofResults();
            ResetButton.Enabled = false;
            HeighttextBox.Enabled = false;
            WeighttextBox.Enabled = false;
        }

        private void MetricUnitButton_CheckedChanged_1(object sender, EventArgs e)
        {
            HeighttextBox.Enabled = true;
            WeighttextBox.Enabled = true;
            resetofall();
            ResetButton.Enabled = false;
            if (ImperialUnitButton.Checked)
            {
                HeighttextBox.Text = "INCH";
                WeighttextBox.Text = "LB";
            }
            else
            {
                HeighttextBox.Text = "M";
                WeighttextBox.Text = "kG";
            }
        }
        private void displayofResults()
        {
            CalculateBMIbutton.Enabled = false;
            BMIlabel.Enabled = false;

        }
        private void Reset(object sender, EventArgs e)
        {
            resetofall();
            ResetButton.Enabled = false;

        }
        private void resetofall()
        {

            HeighttextBox.Text = string.Empty;
            WeighttextBox.Text = string.Empty;

            BMItextBox.Text = string.Empty;
          
        }
        private void ShowResults()
        {
            BMIlabel.Enabled = true;

        }

        private void Height_Click(object sender, EventArgs e)
        {

        }

        private void Weight_Click(object sender, EventArgs e)
        {

        }

        private void inputbox_changed(object sender, EventArgs e)
        {
            if (HeighttextBox.Text == "" || WeighttextBox.Text == "")
            {
                displayofResults();
                ResetButton.Enabled = true;
            }
            else
            {
                CalculateBMIbutton.Enabled = true;
            }
        }

        private void BMItextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void BMICalculator_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
